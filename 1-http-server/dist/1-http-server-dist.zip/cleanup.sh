#!/bin/bash
sudo rm -rf /var/www/html/
