#!/bin/bash
sudo amazon-linux-extras install nginx1